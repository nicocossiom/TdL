from typing import List

# file being analyzed (given as argument)
file: str = ""
# file being analyzed (full path)
file_path = ""
# file lines (list of strings)
file_lines: List[str] = []
# base name of file being analyzed (no path)
file_name: str = ""
# code being analyzed (string)
code: str = ""
output_file = "out.ens"
