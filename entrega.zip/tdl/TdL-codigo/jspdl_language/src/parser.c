#include <tree_sitter/parser.h>

#if defined(__GNUC__) || defined(__clang__)
#pragma GCC diagnostic push
#pragma GCC diagnostic ignored "-Wmissing-field-initializers"
#endif

#define LANGUAGE_VERSION 14
#define STATE_COUNT 173
#define LARGE_STATE_COUNT 2
#define SYMBOL_COUNT 60
#define ALIAS_COUNT 0
#define TOKEN_COUNT 28
#define EXTERNAL_TOKEN_COUNT 0
#define FIELD_COUNT 8
#define MAX_ALIAS_SEQUENCE_LENGTH 7
#define PRODUCTION_ID_COUNT 8

enum {
  anon_sym_int = 1,
  anon_sym_boolean = 2,
  anon_sym_string = 3,
  anon_sym_LBRACE = 4,
  anon_sym_RBRACE = 5,
  anon_sym_SEMI = 6,
  anon_sym_let = 7,
  anon_sym_if = 8,
  anon_sym_LPAREN = 9,
  anon_sym_RPAREN = 10,
  anon_sym_do = 11,
  anon_sym_while = 12,
  anon_sym_return = 13,
  anon_sym_print = 14,
  anon_sym_input = 15,
  anon_sym_EQ = 16,
  anon_sym_PLUS_PLUS = 17,
  anon_sym_COMMA = 18,
  anon_sym_function = 19,
  anon_sym_PIPE_PIPE = 20,
  anon_sym_EQ_EQ = 21,
  anon_sym_PLUS = 22,
  sym_literal_string = 23,
  sym_literal_number = 24,
  anon_sym_true = 25,
  anon_sym_false = 26,
  sym_identifier = 27,
  sym_program = 28,
  sym_type = 29,
  sym__statement_and_declaration = 30,
  sym_block_and_declaration = 31,
  sym_block = 32,
  sym__statement = 33,
  sym_let_statement = 34,
  sym_if_statement = 35,
  sym_do_while_statement = 36,
  sym_return_statement = 37,
  sym_print_statement = 38,
  sym_input_statement = 39,
  sym_function_call = 40,
  sym_assignment_statement = 41,
  sym_post_increment_statement = 42,
  sym_argument_list = 43,
  sym_function_declaration = 44,
  sym_argument_declaration_list = 45,
  sym_argument_declaration = 46,
  sym_parenthesized_expression = 47,
  sym__expression = 48,
  sym_or_expression = 49,
  sym_equality_expression = 50,
  sym_addition_expression = 51,
  sym_value = 52,
  sym__expression_value = 53,
  sym_literal_boolean = 54,
  aux_sym_program_repeat1 = 55,
  aux_sym_block_and_declaration_repeat1 = 56,
  aux_sym_block_repeat1 = 57,
  aux_sym_argument_list_repeat1 = 58,
  aux_sym_argument_declaration_list_repeat1 = 59,
};

static const char * const ts_symbol_names[] = {
  [ts_builtin_sym_end] = "end",
  [anon_sym_int] = "int",
  [anon_sym_boolean] = "boolean",
  [anon_sym_string] = "string",
  [anon_sym_LBRACE] = "{",
  [anon_sym_RBRACE] = "}",
  [anon_sym_SEMI] = ";",
  [anon_sym_let] = "let",
  [anon_sym_if] = "if",
  [anon_sym_LPAREN] = "(",
  [anon_sym_RPAREN] = ")",
  [anon_sym_do] = "do",
  [anon_sym_while] = "while",
  [anon_sym_return] = "return",
  [anon_sym_print] = "print",
  [anon_sym_input] = "input",
  [anon_sym_EQ] = "=",
  [anon_sym_PLUS_PLUS] = "++",
  [anon_sym_COMMA] = ",",
  [anon_sym_function] = "function",
  [anon_sym_PIPE_PIPE] = "||",
  [anon_sym_EQ_EQ] = "==",
  [anon_sym_PLUS] = "+",
  [sym_literal_string] = "literal_string",
  [sym_literal_number] = "literal_number",
  [anon_sym_true] = "true",
  [anon_sym_false] = "false",
  [sym_identifier] = "identifier",
  [sym_program] = "program",
  [sym_type] = "type",
  [sym__statement_and_declaration] = "_statement_and_declaration",
  [sym_block_and_declaration] = "block_and_declaration",
  [sym_block] = "block",
  [sym__statement] = "_statement",
  [sym_let_statement] = "let_statement",
  [sym_if_statement] = "if_statement",
  [sym_do_while_statement] = "do_while_statement",
  [sym_return_statement] = "return_statement",
  [sym_print_statement] = "print_statement",
  [sym_input_statement] = "input_statement",
  [sym_function_call] = "function_call",
  [sym_assignment_statement] = "assignment_statement",
  [sym_post_increment_statement] = "post_increment_statement",
  [sym_argument_list] = "argument_list",
  [sym_function_declaration] = "function_declaration",
  [sym_argument_declaration_list] = "argument_declaration_list",
  [sym_argument_declaration] = "argument_declaration",
  [sym_parenthesized_expression] = "parenthesized_expression",
  [sym__expression] = "_expression",
  [sym_or_expression] = "or_expression",
  [sym_equality_expression] = "equality_expression",
  [sym_addition_expression] = "addition_expression",
  [sym_value] = "value",
  [sym__expression_value] = "_expression_value",
  [sym_literal_boolean] = "literal_boolean",
  [aux_sym_program_repeat1] = "program_repeat1",
  [aux_sym_block_and_declaration_repeat1] = "block_and_declaration_repeat1",
  [aux_sym_block_repeat1] = "block_repeat1",
  [aux_sym_argument_list_repeat1] = "argument_list_repeat1",
  [aux_sym_argument_declaration_list_repeat1] = "argument_declaration_list_repeat1",
};

static const TSSymbol ts_symbol_map[] = {
  [ts_builtin_sym_end] = ts_builtin_sym_end,
  [anon_sym_int] = anon_sym_int,
  [anon_sym_boolean] = anon_sym_boolean,
  [anon_sym_string] = anon_sym_string,
  [anon_sym_LBRACE] = anon_sym_LBRACE,
  [anon_sym_RBRACE] = anon_sym_RBRACE,
  [anon_sym_SEMI] = anon_sym_SEMI,
  [anon_sym_let] = anon_sym_let,
  [anon_sym_if] = anon_sym_if,
  [anon_sym_LPAREN] = anon_sym_LPAREN,
  [anon_sym_RPAREN] = anon_sym_RPAREN,
  [anon_sym_do] = anon_sym_do,
  [anon_sym_while] = anon_sym_while,
  [anon_sym_return] = anon_sym_return,
  [anon_sym_print] = anon_sym_print,
  [anon_sym_input] = anon_sym_input,
  [anon_sym_EQ] = anon_sym_EQ,
  [anon_sym_PLUS_PLUS] = anon_sym_PLUS_PLUS,
  [anon_sym_COMMA] = anon_sym_COMMA,
  [anon_sym_function] = anon_sym_function,
  [anon_sym_PIPE_PIPE] = anon_sym_PIPE_PIPE,
  [anon_sym_EQ_EQ] = anon_sym_EQ_EQ,
  [anon_sym_PLUS] = anon_sym_PLUS,
  [sym_literal_string] = sym_literal_string,
  [sym_literal_number] = sym_literal_number,
  [anon_sym_true] = anon_sym_true,
  [anon_sym_false] = anon_sym_false,
  [sym_identifier] = sym_identifier,
  [sym_program] = sym_program,
  [sym_type] = sym_type,
  [sym__statement_and_declaration] = sym__statement_and_declaration,
  [sym_block_and_declaration] = sym_block_and_declaration,
  [sym_block] = sym_block,
  [sym__statement] = sym__statement,
  [sym_let_statement] = sym_let_statement,
  [sym_if_statement] = sym_if_statement,
  [sym_do_while_statement] = sym_do_while_statement,
  [sym_return_statement] = sym_return_statement,
  [sym_print_statement] = sym_print_statement,
  [sym_input_statement] = sym_input_statement,
  [sym_function_call] = sym_function_call,
  [sym_assignment_statement] = sym_assignment_statement,
  [sym_post_increment_statement] = sym_post_increment_statement,
  [sym_argument_list] = sym_argument_list,
  [sym_function_declaration] = sym_function_declaration,
  [sym_argument_declaration_list] = sym_argument_declaration_list,
  [sym_argument_declaration] = sym_argument_declaration,
  [sym_parenthesized_expression] = sym_parenthesized_expression,
  [sym__expression] = sym__expression,
  [sym_or_expression] = sym_or_expression,
  [sym_equality_expression] = sym_equality_expression,
  [sym_addition_expression] = sym_addition_expression,
  [sym_value] = sym_value,
  [sym__expression_value] = sym__expression_value,
  [sym_literal_boolean] = sym_literal_boolean,
  [aux_sym_program_repeat1] = aux_sym_program_repeat1,
  [aux_sym_block_and_declaration_repeat1] = aux_sym_block_and_declaration_repeat1,
  [aux_sym_block_repeat1] = aux_sym_block_repeat1,
  [aux_sym_argument_list_repeat1] = aux_sym_argument_list_repeat1,
  [aux_sym_argument_declaration_list_repeat1] = aux_sym_argument_declaration_list_repeat1,
};

static const TSSymbolMetadata ts_symbol_metadata[] = {
  [ts_builtin_sym_end] = {
    .visible = false,
    .named = true,
  },
  [anon_sym_int] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_boolean] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_string] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_LBRACE] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_RBRACE] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_SEMI] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_let] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_if] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_LPAREN] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_RPAREN] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_do] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_while] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_return] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_print] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_input] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_EQ] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_PLUS_PLUS] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_COMMA] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_function] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_PIPE_PIPE] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_EQ_EQ] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_PLUS] = {
    .visible = true,
    .named = false,
  },
  [sym_literal_string] = {
    .visible = true,
    .named = true,
  },
  [sym_literal_number] = {
    .visible = true,
    .named = true,
  },
  [anon_sym_true] = {
    .visible = true,
    .named = false,
  },
  [anon_sym_false] = {
    .visible = true,
    .named = false,
  },
  [sym_identifier] = {
    .visible = true,
    .named = true,
  },
  [sym_program] = {
    .visible = true,
    .named = true,
  },
  [sym_type] = {
    .visible = true,
    .named = true,
  },
  [sym__statement_and_declaration] = {
    .visible = false,
    .named = true,
  },
  [sym_block_and_declaration] = {
    .visible = true,
    .named = true,
  },
  [sym_block] = {
    .visible = true,
    .named = true,
  },
  [sym__statement] = {
    .visible = false,
    .named = true,
  },
  [sym_let_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_if_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_do_while_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_return_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_print_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_input_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_function_call] = {
    .visible = true,
    .named = true,
  },
  [sym_assignment_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_post_increment_statement] = {
    .visible = true,
    .named = true,
  },
  [sym_argument_list] = {
    .visible = true,
    .named = true,
  },
  [sym_function_declaration] = {
    .visible = true,
    .named = true,
  },
  [sym_argument_declaration_list] = {
    .visible = true,
    .named = true,
  },
  [sym_argument_declaration] = {
    .visible = true,
    .named = true,
  },
  [sym_parenthesized_expression] = {
    .visible = true,
    .named = true,
  },
  [sym__expression] = {
    .visible = false,
    .named = true,
  },
  [sym_or_expression] = {
    .visible = true,
    .named = true,
  },
  [sym_equality_expression] = {
    .visible = true,
    .named = true,
  },
  [sym_addition_expression] = {
    .visible = true,
    .named = true,
  },
  [sym_value] = {
    .visible = true,
    .named = true,
  },
  [sym__expression_value] = {
    .visible = false,
    .named = true,
  },
  [sym_literal_boolean] = {
    .visible = true,
    .named = true,
  },
  [aux_sym_program_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_block_and_declaration_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_block_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_argument_list_repeat1] = {
    .visible = false,
    .named = false,
  },
  [aux_sym_argument_declaration_list_repeat1] = {
    .visible = false,
    .named = false,
  },
};

enum {
  field_do_while_body = 1,
  field_do_while_condition = 2,
  field_identifier = 3,
  field_if_body = 4,
  field_if_condition = 5,
  field_name = 6,
  field_return_value = 7,
  field_type = 8,
};

static const char * const ts_field_names[] = {
  [0] = NULL,
  [field_do_while_body] = "do_while_body",
  [field_do_while_condition] = "do_while_condition",
  [field_identifier] = "identifier",
  [field_if_body] = "if_body",
  [field_if_condition] = "if_condition",
  [field_name] = "name",
  [field_return_value] = "return_value",
  [field_type] = "type",
};

static const TSFieldMapSlice ts_field_map_slices[PRODUCTION_ID_COUNT] = {
  [1] = {.index = 0, .length = 1},
  [2] = {.index = 1, .length = 1},
  [3] = {.index = 2, .length = 2},
  [4] = {.index = 4, .length = 1},
  [5] = {.index = 5, .length = 2},
  [6] = {.index = 7, .length = 2},
  [7] = {.index = 9, .length = 2},
};

static const TSFieldMapEntry ts_field_map_entries[] = {
  [0] =
    {field_type, 0},
  [1] =
    {field_return_value, 1},
  [2] =
    {field_identifier, 2},
    {field_type, 1},
  [4] =
    {field_identifier, 0},
  [5] =
    {field_if_body, 4},
    {field_if_condition, 2},
  [7] =
    {field_name, 1},
    {field_type, 0},
  [9] =
    {field_do_while_body, 1},
    {field_do_while_condition, 4},
};

static const TSSymbol ts_alias_sequences[PRODUCTION_ID_COUNT][MAX_ALIAS_SEQUENCE_LENGTH] = {
  [0] = {0},
};

static const uint16_t ts_non_terminal_alias_map[] = {
  0,
};

static const TSStateId ts_primary_state_ids[STATE_COUNT] = {
  [0] = 0,
  [1] = 1,
  [2] = 2,
  [3] = 3,
  [4] = 4,
  [5] = 5,
  [6] = 6,
  [7] = 5,
  [8] = 6,
  [9] = 9,
  [10] = 10,
  [11] = 11,
  [12] = 12,
  [13] = 12,
  [14] = 14,
  [15] = 10,
  [16] = 11,
  [17] = 10,
  [18] = 12,
  [19] = 14,
  [20] = 14,
  [21] = 11,
  [22] = 22,
  [23] = 23,
  [24] = 24,
  [25] = 25,
  [26] = 26,
  [27] = 27,
  [28] = 28,
  [29] = 25,
  [30] = 23,
  [31] = 26,
  [32] = 23,
  [33] = 25,
  [34] = 26,
  [35] = 28,
  [36] = 28,
  [37] = 37,
  [38] = 38,
  [39] = 39,
  [40] = 40,
  [41] = 41,
  [42] = 42,
  [43] = 43,
  [44] = 44,
  [45] = 45,
  [46] = 46,
  [47] = 47,
  [48] = 48,
  [49] = 49,
  [50] = 50,
  [51] = 51,
  [52] = 52,
  [53] = 53,
  [54] = 54,
  [55] = 41,
  [56] = 51,
  [57] = 57,
  [58] = 50,
  [59] = 48,
  [60] = 60,
  [61] = 49,
  [62] = 47,
  [63] = 46,
  [64] = 40,
  [65] = 52,
  [66] = 42,
  [67] = 45,
  [68] = 52,
  [69] = 40,
  [70] = 49,
  [71] = 50,
  [72] = 47,
  [73] = 41,
  [74] = 46,
  [75] = 48,
  [76] = 42,
  [77] = 45,
  [78] = 78,
  [79] = 79,
  [80] = 80,
  [81] = 81,
  [82] = 82,
  [83] = 83,
  [84] = 84,
  [85] = 85,
  [86] = 86,
  [87] = 87,
  [88] = 88,
  [89] = 89,
  [90] = 90,
  [91] = 91,
  [92] = 92,
  [93] = 93,
  [94] = 94,
  [95] = 91,
  [96] = 96,
  [97] = 93,
  [98] = 94,
  [99] = 91,
  [100] = 96,
  [101] = 94,
  [102] = 102,
  [103] = 103,
  [104] = 103,
  [105] = 96,
  [106] = 102,
  [107] = 103,
  [108] = 102,
  [109] = 109,
  [110] = 109,
  [111] = 111,
  [112] = 109,
  [113] = 113,
  [114] = 114,
  [115] = 115,
  [116] = 116,
  [117] = 117,
  [118] = 118,
  [119] = 119,
  [120] = 119,
  [121] = 119,
  [122] = 122,
  [123] = 123,
  [124] = 124,
  [125] = 125,
  [126] = 126,
  [127] = 127,
  [128] = 128,
  [129] = 129,
  [130] = 130,
  [131] = 131,
  [132] = 132,
  [133] = 133,
  [134] = 134,
  [135] = 135,
  [136] = 129,
  [137] = 130,
  [138] = 127,
  [139] = 133,
  [140] = 140,
  [141] = 134,
  [142] = 130,
  [143] = 143,
  [144] = 133,
  [145] = 145,
  [146] = 146,
  [147] = 54,
  [148] = 143,
  [149] = 131,
  [150] = 150,
  [151] = 151,
  [152] = 134,
  [153] = 153,
  [154] = 132,
  [155] = 155,
  [156] = 143,
  [157] = 157,
  [158] = 158,
  [159] = 132,
  [160] = 160,
  [161] = 160,
  [162] = 157,
  [163] = 155,
  [164] = 151,
  [165] = 160,
  [166] = 157,
  [167] = 155,
  [168] = 151,
  [169] = 135,
  [170] = 135,
  [171] = 44,
  [172] = 129,
};

static bool ts_lex(TSLexer *lexer, TSStateId state) {
  START_LEXER();
  eof = lexer->eof(lexer);
  switch (state) {
    case 0:
      if (eof) ADVANCE(79);
      if (lookahead == '\t' ||
          lookahead == '\n' ||
          lookahead == '\r' ||
          lookahead == ' ' ||
          lookahead == 160) SKIP(0)
      if (lookahead == '"') ADVANCE(5);
      if (lookahead == '(') ADVANCE(90);
      if (lookahead == ')') ADVANCE(91);
      if (lookahead == '+') ADVANCE(109);
      if (lookahead == ',') ADVANCE(104);
      if (lookahead == '-') ADVANCE(69);
      if (lookahead == '/') SKIP(72)
      if (lookahead == ';') ADVANCE(85);
      if (lookahead == '=') ADVANCE(102);
      if (lookahead == 'b') ADVANCE(47);
      if (lookahead == 'd') ADVANCE(45);
      if (lookahead == 'f') ADVANCE(20);
      if (lookahead == 'i') ADVANCE(29);
      if (lookahead == 'l') ADVANCE(27);
      if (lookahead == 'p') ADVANCE(50);
      if (lookahead == 'r') ADVANCE(28);
      if (lookahead == 's') ADVANCE(60);
      if (lookahead == 't') ADVANCE(51);
      if (lookahead == 'w') ADVANCE(31);
      if (lookahead == '{') ADVANCE(83);
      if (lookahead == '|') ADVANCE(64);
      if (lookahead == '}') ADVANCE(84);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(111);
      END_STATE();
    case 1:
      if (lookahead == '\n') SKIP(65)
      if (lookahead != 0) SKIP(1)
      END_STATE();
    case 2:
      if (lookahead == '\n') SKIP(66)
      if (lookahead != 0) SKIP(2)
      END_STATE();
    case 3:
      if (lookahead == '\n') SKIP(67)
      if (lookahead != 0) SKIP(3)
      END_STATE();
    case 4:
      if (lookahead == '\n') SKIP(68)
      if (lookahead != 0) SKIP(4)
      END_STATE();
    case 5:
      if (lookahead == '"') ADVANCE(110);
      if (lookahead != 0) ADVANCE(5);
      END_STATE();
    case 6:
      if (lookahead == '*') SKIP(8)
      if (lookahead == '/') SKIP(1)
      END_STATE();
    case 7:
      if (lookahead == '*') SKIP(7)
      if (lookahead == '/') SKIP(65)
      if (lookahead != 0) SKIP(8)
      END_STATE();
    case 8:
      if (lookahead == '*') SKIP(7)
      if (lookahead != 0) SKIP(8)
      END_STATE();
    case 9:
      if (lookahead == '*') SKIP(9)
      if (lookahead == '/') SKIP(66)
      if (lookahead != 0) SKIP(10)
      END_STATE();
    case 10:
      if (lookahead == '*') SKIP(9)
      if (lookahead != 0) SKIP(10)
      END_STATE();
    case 11:
      if (lookahead == '*') SKIP(11)
      if (lookahead == '/') SKIP(67)
      if (lookahead != 0) SKIP(12)
      END_STATE();
    case 12:
      if (lookahead == '*') SKIP(11)
      if (lookahead != 0) SKIP(12)
      END_STATE();
    case 13:
      if (lookahead == '*') SKIP(13)
      if (lookahead == '/') SKIP(68)
      if (lookahead != 0) SKIP(14)
      END_STATE();
    case 14:
      if (lookahead == '*') SKIP(13)
      if (lookahead != 0) SKIP(14)
      END_STATE();
    case 15:
      if (lookahead == '*') SKIP(10)
      if (lookahead == '/') SKIP(2)
      END_STATE();
    case 16:
      if (lookahead == '*') SKIP(12)
      if (lookahead == '/') SKIP(3)
      END_STATE();
    case 17:
      if (lookahead == '*') SKIP(14)
      if (lookahead == '/') SKIP(4)
      END_STATE();
    case 18:
      if (lookahead == '+') ADVANCE(103);
      END_STATE();
    case 19:
      if (lookahead == '=') ADVANCE(108);
      END_STATE();
    case 20:
      if (lookahead == 'a') ADVANCE(36);
      if (lookahead == 'u') ADVANCE(39);
      END_STATE();
    case 21:
      if (lookahead == 'a') ADVANCE(42);
      END_STATE();
    case 22:
      if (lookahead == 'c') ADVANCE(58);
      END_STATE();
    case 23:
      if (lookahead == 'e') ADVANCE(112);
      END_STATE();
    case 24:
      if (lookahead == 'e') ADVANCE(21);
      END_STATE();
    case 25:
      if (lookahead == 'e') ADVANCE(114);
      END_STATE();
    case 26:
      if (lookahead == 'e') ADVANCE(94);
      END_STATE();
    case 27:
      if (lookahead == 'e') ADVANCE(55);
      END_STATE();
    case 28:
      if (lookahead == 'e') ADVANCE(59);
      END_STATE();
    case 29:
      if (lookahead == 'f') ADVANCE(88);
      if (lookahead == 'n') ADVANCE(49);
      END_STATE();
    case 30:
      if (lookahead == 'g') ADVANCE(82);
      END_STATE();
    case 31:
      if (lookahead == 'h') ADVANCE(35);
      END_STATE();
    case 32:
      if (lookahead == 'i') ADVANCE(44);
      END_STATE();
    case 33:
      if (lookahead == 'i') ADVANCE(40);
      END_STATE();
    case 34:
      if (lookahead == 'i') ADVANCE(48);
      END_STATE();
    case 35:
      if (lookahead == 'i') ADVANCE(38);
      END_STATE();
    case 36:
      if (lookahead == 'l') ADVANCE(54);
      END_STATE();
    case 37:
      if (lookahead == 'l') ADVANCE(24);
      END_STATE();
    case 38:
      if (lookahead == 'l') ADVANCE(26);
      END_STATE();
    case 39:
      if (lookahead == 'n') ADVANCE(22);
      END_STATE();
    case 40:
      if (lookahead == 'n') ADVANCE(30);
      END_STATE();
    case 41:
      if (lookahead == 'n') ADVANCE(95);
      END_STATE();
    case 42:
      if (lookahead == 'n') ADVANCE(81);
      END_STATE();
    case 43:
      if (lookahead == 'n') ADVANCE(105);
      END_STATE();
    case 44:
      if (lookahead == 'n') ADVANCE(57);
      END_STATE();
    case 45:
      if (lookahead == 'o') ADVANCE(92);
      END_STATE();
    case 46:
      if (lookahead == 'o') ADVANCE(37);
      END_STATE();
    case 47:
      if (lookahead == 'o') ADVANCE(46);
      END_STATE();
    case 48:
      if (lookahead == 'o') ADVANCE(43);
      END_STATE();
    case 49:
      if (lookahead == 'p') ADVANCE(63);
      if (lookahead == 't') ADVANCE(80);
      END_STATE();
    case 50:
      if (lookahead == 'r') ADVANCE(32);
      END_STATE();
    case 51:
      if (lookahead == 'r') ADVANCE(61);
      END_STATE();
    case 52:
      if (lookahead == 'r') ADVANCE(41);
      END_STATE();
    case 53:
      if (lookahead == 'r') ADVANCE(33);
      END_STATE();
    case 54:
      if (lookahead == 's') ADVANCE(25);
      END_STATE();
    case 55:
      if (lookahead == 't') ADVANCE(86);
      END_STATE();
    case 56:
      if (lookahead == 't') ADVANCE(99);
      END_STATE();
    case 57:
      if (lookahead == 't') ADVANCE(97);
      END_STATE();
    case 58:
      if (lookahead == 't') ADVANCE(34);
      END_STATE();
    case 59:
      if (lookahead == 't') ADVANCE(62);
      END_STATE();
    case 60:
      if (lookahead == 't') ADVANCE(53);
      END_STATE();
    case 61:
      if (lookahead == 'u') ADVANCE(23);
      END_STATE();
    case 62:
      if (lookahead == 'u') ADVANCE(52);
      END_STATE();
    case 63:
      if (lookahead == 'u') ADVANCE(56);
      END_STATE();
    case 64:
      if (lookahead == '|') ADVANCE(107);
      END_STATE();
    case 65:
      if (lookahead == '\t' ||
          lookahead == '\n' ||
          lookahead == '\r' ||
          lookahead == ' ' ||
          lookahead == 160) SKIP(65)
      if (lookahead == '(') ADVANCE(90);
      if (lookahead == '+') ADVANCE(18);
      if (lookahead == '/') SKIP(6)
      if (lookahead == '=') ADVANCE(101);
      if (lookahead == 'd') ADVANCE(130);
      if (lookahead == 'i') ADVANCE(122);
      if (lookahead == 'l') ADVANCE(118);
      if (lookahead == 'p') ADVANCE(133);
      if (lookahead == 'r') ADVANCE(121);
      if (lookahead == '}') ADVANCE(84);
      if (('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 66:
      if (lookahead == '\t' ||
          lookahead == '\n' ||
          lookahead == '\r' ||
          lookahead == ' ' ||
          lookahead == 160) SKIP(66)
      if (lookahead == '"') ADVANCE(5);
      if (lookahead == '(') ADVANCE(90);
      if (lookahead == ')') ADVANCE(91);
      if (lookahead == '-') ADVANCE(69);
      if (lookahead == '/') SKIP(15)
      if (lookahead == ';') ADVANCE(85);
      if (lookahead == 'f') ADVANCE(116);
      if (lookahead == 't') ADVANCE(135);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(111);
      if (('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 67:
      if (lookahead == '\t' ||
          lookahead == '\n' ||
          lookahead == '\r' ||
          lookahead == ' ' ||
          lookahead == 160) SKIP(67)
      if (lookahead == '/') SKIP(16)
      if (lookahead == 'd') ADVANCE(130);
      if (lookahead == 'i') ADVANCE(122);
      if (lookahead == 'p') ADVANCE(133);
      if (lookahead == 'r') ADVANCE(121);
      if (lookahead == '{') ADVANCE(83);
      if (lookahead == '}') ADVANCE(84);
      if (('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 68:
      if (lookahead == '\t' ||
          lookahead == '\n' ||
          lookahead == '\r' ||
          lookahead == ' ' ||
          lookahead == 160) SKIP(68)
      if (lookahead == '(') ADVANCE(90);
      if (lookahead == '/') SKIP(17)
      if (('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 69:
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(111);
      END_STATE();
    case 70:
      if (eof) ADVANCE(79);
      if (lookahead == '\n') SKIP(0)
      if (lookahead != 0) SKIP(70)
      END_STATE();
    case 71:
      if (eof) ADVANCE(79);
      if (lookahead == '\n') SKIP(78)
      if (lookahead != 0) SKIP(71)
      END_STATE();
    case 72:
      if (eof) ADVANCE(79);
      if (lookahead == '*') SKIP(74)
      if (lookahead == '/') SKIP(70)
      END_STATE();
    case 73:
      if (eof) ADVANCE(79);
      if (lookahead == '*') SKIP(73)
      if (lookahead == '/') SKIP(0)
      if (lookahead != 0) SKIP(74)
      END_STATE();
    case 74:
      if (eof) ADVANCE(79);
      if (lookahead == '*') SKIP(73)
      if (lookahead != 0) SKIP(74)
      END_STATE();
    case 75:
      if (eof) ADVANCE(79);
      if (lookahead == '*') SKIP(75)
      if (lookahead == '/') SKIP(78)
      if (lookahead != 0) SKIP(76)
      END_STATE();
    case 76:
      if (eof) ADVANCE(79);
      if (lookahead == '*') SKIP(75)
      if (lookahead != 0) SKIP(76)
      END_STATE();
    case 77:
      if (eof) ADVANCE(79);
      if (lookahead == '*') SKIP(76)
      if (lookahead == '/') SKIP(71)
      END_STATE();
    case 78:
      if (eof) ADVANCE(79);
      if (lookahead == '\t' ||
          lookahead == '\n' ||
          lookahead == '\r' ||
          lookahead == ' ' ||
          lookahead == 160) SKIP(78)
      if (lookahead == '(') ADVANCE(90);
      if (lookahead == ')') ADVANCE(91);
      if (lookahead == '+') ADVANCE(109);
      if (lookahead == ',') ADVANCE(104);
      if (lookahead == '/') SKIP(77)
      if (lookahead == ';') ADVANCE(85);
      if (lookahead == '=') ADVANCE(19);
      if (lookahead == 'd') ADVANCE(130);
      if (lookahead == 'f') ADVANCE(142);
      if (lookahead == 'i') ADVANCE(122);
      if (lookahead == 'l') ADVANCE(118);
      if (lookahead == 'p') ADVANCE(133);
      if (lookahead == 'r') ADVANCE(121);
      if (lookahead == '|') ADVANCE(64);
      if (('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 79:
      ACCEPT_TOKEN(ts_builtin_sym_end);
      END_STATE();
    case 80:
      ACCEPT_TOKEN(anon_sym_int);
      END_STATE();
    case 81:
      ACCEPT_TOKEN(anon_sym_boolean);
      END_STATE();
    case 82:
      ACCEPT_TOKEN(anon_sym_string);
      END_STATE();
    case 83:
      ACCEPT_TOKEN(anon_sym_LBRACE);
      END_STATE();
    case 84:
      ACCEPT_TOKEN(anon_sym_RBRACE);
      END_STATE();
    case 85:
      ACCEPT_TOKEN(anon_sym_SEMI);
      END_STATE();
    case 86:
      ACCEPT_TOKEN(anon_sym_let);
      END_STATE();
    case 87:
      ACCEPT_TOKEN(anon_sym_let);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 88:
      ACCEPT_TOKEN(anon_sym_if);
      END_STATE();
    case 89:
      ACCEPT_TOKEN(anon_sym_if);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 90:
      ACCEPT_TOKEN(anon_sym_LPAREN);
      END_STATE();
    case 91:
      ACCEPT_TOKEN(anon_sym_RPAREN);
      END_STATE();
    case 92:
      ACCEPT_TOKEN(anon_sym_do);
      END_STATE();
    case 93:
      ACCEPT_TOKEN(anon_sym_do);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 94:
      ACCEPT_TOKEN(anon_sym_while);
      END_STATE();
    case 95:
      ACCEPT_TOKEN(anon_sym_return);
      END_STATE();
    case 96:
      ACCEPT_TOKEN(anon_sym_return);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 97:
      ACCEPT_TOKEN(anon_sym_print);
      END_STATE();
    case 98:
      ACCEPT_TOKEN(anon_sym_print);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 99:
      ACCEPT_TOKEN(anon_sym_input);
      END_STATE();
    case 100:
      ACCEPT_TOKEN(anon_sym_input);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 101:
      ACCEPT_TOKEN(anon_sym_EQ);
      END_STATE();
    case 102:
      ACCEPT_TOKEN(anon_sym_EQ);
      if (lookahead == '=') ADVANCE(108);
      END_STATE();
    case 103:
      ACCEPT_TOKEN(anon_sym_PLUS_PLUS);
      END_STATE();
    case 104:
      ACCEPT_TOKEN(anon_sym_COMMA);
      END_STATE();
    case 105:
      ACCEPT_TOKEN(anon_sym_function);
      END_STATE();
    case 106:
      ACCEPT_TOKEN(anon_sym_function);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 107:
      ACCEPT_TOKEN(anon_sym_PIPE_PIPE);
      END_STATE();
    case 108:
      ACCEPT_TOKEN(anon_sym_EQ_EQ);
      END_STATE();
    case 109:
      ACCEPT_TOKEN(anon_sym_PLUS);
      if (lookahead == '+') ADVANCE(103);
      END_STATE();
    case 110:
      ACCEPT_TOKEN(sym_literal_string);
      END_STATE();
    case 111:
      ACCEPT_TOKEN(sym_literal_number);
      if (('0' <= lookahead && lookahead <= '9')) ADVANCE(111);
      END_STATE();
    case 112:
      ACCEPT_TOKEN(anon_sym_true);
      END_STATE();
    case 113:
      ACCEPT_TOKEN(anon_sym_true);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 114:
      ACCEPT_TOKEN(anon_sym_false);
      END_STATE();
    case 115:
      ACCEPT_TOKEN(anon_sym_false);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 116:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'a') ADVANCE(125);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('b' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 117:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'c') ADVANCE(140);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 118:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'e') ADVANCE(137);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 119:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'e') ADVANCE(113);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 120:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'e') ADVANCE(115);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 121:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'e') ADVANCE(141);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 122:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'f') ADVANCE(89);
      if (lookahead == 'n') ADVANCE(132);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 123:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'i') ADVANCE(131);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 124:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'i') ADVANCE(129);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 125:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'l') ADVANCE(136);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 126:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'n') ADVANCE(117);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 127:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'n') ADVANCE(96);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 128:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'n') ADVANCE(106);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 129:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'n') ADVANCE(139);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 130:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'o') ADVANCE(93);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 131:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'o') ADVANCE(128);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 132:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'p') ADVANCE(145);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 133:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'r') ADVANCE(124);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 134:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'r') ADVANCE(127);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 135:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'r') ADVANCE(143);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 136:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 's') ADVANCE(120);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 137:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 't') ADVANCE(87);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 138:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 't') ADVANCE(100);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 139:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 't') ADVANCE(98);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 140:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 't') ADVANCE(123);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 141:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 't') ADVANCE(144);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 142:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'u') ADVANCE(126);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 143:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'u') ADVANCE(119);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 144:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'u') ADVANCE(134);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 145:
      ACCEPT_TOKEN(sym_identifier);
      if (lookahead == 'u') ADVANCE(138);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    case 146:
      ACCEPT_TOKEN(sym_identifier);
      if (('0' <= lookahead && lookahead <= '9') ||
          ('A' <= lookahead && lookahead <= 'Z') ||
          lookahead == '_' ||
          ('a' <= lookahead && lookahead <= 'z')) ADVANCE(146);
      END_STATE();
    default:
      return false;
  }
}

static const TSLexMode ts_lex_modes[STATE_COUNT] = {
  [0] = {.lex_state = 0},
  [1] = {.lex_state = 78},
  [2] = {.lex_state = 78},
  [3] = {.lex_state = 78},
  [4] = {.lex_state = 65},
  [5] = {.lex_state = 65},
  [6] = {.lex_state = 65},
  [7] = {.lex_state = 65},
  [8] = {.lex_state = 65},
  [9] = {.lex_state = 66},
  [10] = {.lex_state = 67},
  [11] = {.lex_state = 67},
  [12] = {.lex_state = 66},
  [13] = {.lex_state = 66},
  [14] = {.lex_state = 67},
  [15] = {.lex_state = 67},
  [16] = {.lex_state = 67},
  [17] = {.lex_state = 67},
  [18] = {.lex_state = 66},
  [19] = {.lex_state = 67},
  [20] = {.lex_state = 67},
  [21] = {.lex_state = 67},
  [22] = {.lex_state = 67},
  [23] = {.lex_state = 66},
  [24] = {.lex_state = 66},
  [25] = {.lex_state = 66},
  [26] = {.lex_state = 66},
  [27] = {.lex_state = 66},
  [28] = {.lex_state = 66},
  [29] = {.lex_state = 66},
  [30] = {.lex_state = 66},
  [31] = {.lex_state = 66},
  [32] = {.lex_state = 66},
  [33] = {.lex_state = 66},
  [34] = {.lex_state = 66},
  [35] = {.lex_state = 66},
  [36] = {.lex_state = 66},
  [37] = {.lex_state = 66},
  [38] = {.lex_state = 66},
  [39] = {.lex_state = 66},
  [40] = {.lex_state = 78},
  [41] = {.lex_state = 78},
  [42] = {.lex_state = 78},
  [43] = {.lex_state = 78},
  [44] = {.lex_state = 78},
  [45] = {.lex_state = 78},
  [46] = {.lex_state = 78},
  [47] = {.lex_state = 78},
  [48] = {.lex_state = 78},
  [49] = {.lex_state = 78},
  [50] = {.lex_state = 78},
  [51] = {.lex_state = 78},
  [52] = {.lex_state = 78},
  [53] = {.lex_state = 78},
  [54] = {.lex_state = 78},
  [55] = {.lex_state = 65},
  [56] = {.lex_state = 65},
  [57] = {.lex_state = 78},
  [58] = {.lex_state = 65},
  [59] = {.lex_state = 65},
  [60] = {.lex_state = 0},
  [61] = {.lex_state = 65},
  [62] = {.lex_state = 65},
  [63] = {.lex_state = 65},
  [64] = {.lex_state = 65},
  [65] = {.lex_state = 65},
  [66] = {.lex_state = 65},
  [67] = {.lex_state = 65},
  [68] = {.lex_state = 67},
  [69] = {.lex_state = 67},
  [70] = {.lex_state = 67},
  [71] = {.lex_state = 67},
  [72] = {.lex_state = 67},
  [73] = {.lex_state = 67},
  [74] = {.lex_state = 67},
  [75] = {.lex_state = 67},
  [76] = {.lex_state = 67},
  [77] = {.lex_state = 67},
  [78] = {.lex_state = 78},
  [79] = {.lex_state = 78},
  [80] = {.lex_state = 78},
  [81] = {.lex_state = 78},
  [82] = {.lex_state = 78},
  [83] = {.lex_state = 78},
  [84] = {.lex_state = 78},
  [85] = {.lex_state = 0},
  [86] = {.lex_state = 78},
  [87] = {.lex_state = 78},
  [88] = {.lex_state = 78},
  [89] = {.lex_state = 78},
  [90] = {.lex_state = 0},
  [91] = {.lex_state = 78},
  [92] = {.lex_state = 78},
  [93] = {.lex_state = 0},
  [94] = {.lex_state = 78},
  [95] = {.lex_state = 78},
  [96] = {.lex_state = 78},
  [97] = {.lex_state = 0},
  [98] = {.lex_state = 78},
  [99] = {.lex_state = 78},
  [100] = {.lex_state = 78},
  [101] = {.lex_state = 78},
  [102] = {.lex_state = 78},
  [103] = {.lex_state = 78},
  [104] = {.lex_state = 78},
  [105] = {.lex_state = 78},
  [106] = {.lex_state = 78},
  [107] = {.lex_state = 78},
  [108] = {.lex_state = 78},
  [109] = {.lex_state = 65},
  [110] = {.lex_state = 65},
  [111] = {.lex_state = 0},
  [112] = {.lex_state = 65},
  [113] = {.lex_state = 0},
  [114] = {.lex_state = 0},
  [115] = {.lex_state = 0},
  [116] = {.lex_state = 0},
  [117] = {.lex_state = 0},
  [118] = {.lex_state = 0},
  [119] = {.lex_state = 0},
  [120] = {.lex_state = 0},
  [121] = {.lex_state = 0},
  [122] = {.lex_state = 0},
  [123] = {.lex_state = 0},
  [124] = {.lex_state = 0},
  [125] = {.lex_state = 0},
  [126] = {.lex_state = 68},
  [127] = {.lex_state = 68},
  [128] = {.lex_state = 0},
  [129] = {.lex_state = 0},
  [130] = {.lex_state = 0},
  [131] = {.lex_state = 0},
  [132] = {.lex_state = 68},
  [133] = {.lex_state = 0},
  [134] = {.lex_state = 0},
  [135] = {.lex_state = 0},
  [136] = {.lex_state = 0},
  [137] = {.lex_state = 0},
  [138] = {.lex_state = 68},
  [139] = {.lex_state = 0},
  [140] = {.lex_state = 0},
  [141] = {.lex_state = 0},
  [142] = {.lex_state = 0},
  [143] = {.lex_state = 0},
  [144] = {.lex_state = 0},
  [145] = {.lex_state = 0},
  [146] = {.lex_state = 0},
  [147] = {.lex_state = 0},
  [148] = {.lex_state = 0},
  [149] = {.lex_state = 0},
  [150] = {.lex_state = 68},
  [151] = {.lex_state = 0},
  [152] = {.lex_state = 0},
  [153] = {.lex_state = 68},
  [154] = {.lex_state = 68},
  [155] = {.lex_state = 0},
  [156] = {.lex_state = 0},
  [157] = {.lex_state = 0},
  [158] = {.lex_state = 0},
  [159] = {.lex_state = 68},
  [160] = {.lex_state = 0},
  [161] = {.lex_state = 0},
  [162] = {.lex_state = 0},
  [163] = {.lex_state = 0},
  [164] = {.lex_state = 0},
  [165] = {.lex_state = 0},
  [166] = {.lex_state = 0},
  [167] = {.lex_state = 0},
  [168] = {.lex_state = 0},
  [169] = {.lex_state = 0},
  [170] = {.lex_state = 0},
  [171] = {.lex_state = 0},
  [172] = {.lex_state = 0},
};

static const uint16_t ts_parse_table[LARGE_STATE_COUNT][SYMBOL_COUNT] = {
  [0] = {
    [ts_builtin_sym_end] = ACTIONS(1),
    [anon_sym_int] = ACTIONS(1),
    [anon_sym_boolean] = ACTIONS(1),
    [anon_sym_string] = ACTIONS(1),
    [anon_sym_LBRACE] = ACTIONS(1),
    [anon_sym_RBRACE] = ACTIONS(1),
    [anon_sym_SEMI] = ACTIONS(1),
    [anon_sym_let] = ACTIONS(1),
    [anon_sym_if] = ACTIONS(1),
    [anon_sym_LPAREN] = ACTIONS(1),
    [anon_sym_RPAREN] = ACTIONS(1),
    [anon_sym_do] = ACTIONS(1),
    [anon_sym_while] = ACTIONS(1),
    [anon_sym_return] = ACTIONS(1),
    [anon_sym_print] = ACTIONS(1),
    [anon_sym_input] = ACTIONS(1),
    [anon_sym_EQ] = ACTIONS(1),
    [anon_sym_PLUS_PLUS] = ACTIONS(1),
    [anon_sym_COMMA] = ACTIONS(1),
    [anon_sym_function] = ACTIONS(1),
    [anon_sym_PIPE_PIPE] = ACTIONS(1),
    [anon_sym_EQ_EQ] = ACTIONS(1),
    [anon_sym_PLUS] = ACTIONS(1),
    [sym_literal_string] = ACTIONS(1),
    [sym_literal_number] = ACTIONS(1),
    [anon_sym_true] = ACTIONS(1),
    [anon_sym_false] = ACTIONS(1),
  },
  [1] = {
    [sym_program] = STATE(145),
    [sym__statement_and_declaration] = STATE(3),
    [sym__statement] = STATE(3),
    [sym_let_statement] = STATE(3),
    [sym_if_statement] = STATE(3),
    [sym_do_while_statement] = STATE(3),
    [sym_return_statement] = STATE(3),
    [sym_print_statement] = STATE(3),
    [sym_input_statement] = STATE(3),
    [sym_function_call] = STATE(141),
    [sym_assignment_statement] = STATE(3),
    [sym_post_increment_statement] = STATE(141),
    [sym_function_declaration] = STATE(3),
    [aux_sym_program_repeat1] = STATE(3),
    [ts_builtin_sym_end] = ACTIONS(3),
    [anon_sym_let] = ACTIONS(5),
    [anon_sym_if] = ACTIONS(7),
    [anon_sym_do] = ACTIONS(9),
    [anon_sym_return] = ACTIONS(11),
    [anon_sym_print] = ACTIONS(13),
    [anon_sym_input] = ACTIONS(15),
    [anon_sym_function] = ACTIONS(17),
    [sym_identifier] = ACTIONS(19),
  },
};

static const uint16_t ts_small_parse_table[] = {
  [0] = 11,
    ACTIONS(21), 1,
      ts_builtin_sym_end,
    ACTIONS(23), 1,
      anon_sym_let,
    ACTIONS(26), 1,
      anon_sym_if,
    ACTIONS(29), 1,
      anon_sym_do,
    ACTIONS(32), 1,
      anon_sym_return,
    ACTIONS(35), 1,
      anon_sym_print,
    ACTIONS(38), 1,
      anon_sym_input,
    ACTIONS(41), 1,
      anon_sym_function,
    ACTIONS(44), 1,
      sym_identifier,
    STATE(141), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(2), 11,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      sym_function_declaration,
      aux_sym_program_repeat1,
  [45] = 11,
    ACTIONS(5), 1,
      anon_sym_let,
    ACTIONS(7), 1,
      anon_sym_if,
    ACTIONS(9), 1,
      anon_sym_do,
    ACTIONS(11), 1,
      anon_sym_return,
    ACTIONS(13), 1,
      anon_sym_print,
    ACTIONS(15), 1,
      anon_sym_input,
    ACTIONS(17), 1,
      anon_sym_function,
    ACTIONS(19), 1,
      sym_identifier,
    ACTIONS(47), 1,
      ts_builtin_sym_end,
    STATE(141), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(2), 11,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      sym_function_declaration,
      aux_sym_program_repeat1,
  [90] = 10,
    ACTIONS(49), 1,
      anon_sym_RBRACE,
    ACTIONS(51), 1,
      anon_sym_let,
    ACTIONS(54), 1,
      anon_sym_if,
    ACTIONS(57), 1,
      anon_sym_do,
    ACTIONS(60), 1,
      anon_sym_return,
    ACTIONS(63), 1,
      anon_sym_print,
    ACTIONS(66), 1,
      anon_sym_input,
    ACTIONS(69), 1,
      sym_identifier,
    STATE(152), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(4), 10,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_and_declaration_repeat1,
  [131] = 10,
    ACTIONS(72), 1,
      anon_sym_RBRACE,
    ACTIONS(74), 1,
      anon_sym_let,
    ACTIONS(76), 1,
      anon_sym_if,
    ACTIONS(78), 1,
      anon_sym_do,
    ACTIONS(80), 1,
      anon_sym_return,
    ACTIONS(82), 1,
      anon_sym_print,
    ACTIONS(84), 1,
      anon_sym_input,
    ACTIONS(86), 1,
      sym_identifier,
    STATE(152), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(4), 10,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_and_declaration_repeat1,
  [172] = 10,
    ACTIONS(74), 1,
      anon_sym_let,
    ACTIONS(76), 1,
      anon_sym_if,
    ACTIONS(78), 1,
      anon_sym_do,
    ACTIONS(80), 1,
      anon_sym_return,
    ACTIONS(82), 1,
      anon_sym_print,
    ACTIONS(84), 1,
      anon_sym_input,
    ACTIONS(86), 1,
      sym_identifier,
    ACTIONS(88), 1,
      anon_sym_RBRACE,
    STATE(152), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(7), 10,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_and_declaration_repeat1,
  [213] = 10,
    ACTIONS(74), 1,
      anon_sym_let,
    ACTIONS(76), 1,
      anon_sym_if,
    ACTIONS(78), 1,
      anon_sym_do,
    ACTIONS(80), 1,
      anon_sym_return,
    ACTIONS(82), 1,
      anon_sym_print,
    ACTIONS(84), 1,
      anon_sym_input,
    ACTIONS(86), 1,
      sym_identifier,
    ACTIONS(90), 1,
      anon_sym_RBRACE,
    STATE(152), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(4), 10,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_and_declaration_repeat1,
  [254] = 10,
    ACTIONS(74), 1,
      anon_sym_let,
    ACTIONS(76), 1,
      anon_sym_if,
    ACTIONS(78), 1,
      anon_sym_do,
    ACTIONS(80), 1,
      anon_sym_return,
    ACTIONS(82), 1,
      anon_sym_print,
    ACTIONS(84), 1,
      anon_sym_input,
    ACTIONS(86), 1,
      sym_identifier,
    ACTIONS(92), 1,
      anon_sym_RBRACE,
    STATE(152), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(5), 10,
      sym__statement_and_declaration,
      sym__statement,
      sym_let_statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_and_declaration_repeat1,
  [295] = 8,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(96), 1,
      anon_sym_RPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    STATE(158), 1,
      sym_argument_list,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(84), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
  [330] = 9,
    ACTIONS(104), 1,
      anon_sym_RBRACE,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(20), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [366] = 9,
    ACTIONS(76), 1,
      anon_sym_if,
    ACTIONS(78), 1,
      anon_sym_do,
    ACTIONS(80), 1,
      anon_sym_return,
    ACTIONS(82), 1,
      anon_sym_print,
    ACTIONS(84), 1,
      anon_sym_input,
    ACTIONS(86), 1,
      sym_identifier,
    ACTIONS(118), 1,
      anon_sym_LBRACE,
    STATE(152), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(62), 8,
      sym_block,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
  [402] = 7,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(120), 1,
      anon_sym_SEMI,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(107), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [434] = 7,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(122), 1,
      anon_sym_SEMI,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(104), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [466] = 9,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    ACTIONS(124), 1,
      anon_sym_RBRACE,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(22), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [502] = 9,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    ACTIONS(126), 1,
      anon_sym_RBRACE,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(14), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [538] = 9,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    ACTIONS(128), 1,
      anon_sym_LBRACE,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(72), 8,
      sym_block,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
  [574] = 9,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    ACTIONS(130), 1,
      anon_sym_RBRACE,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(19), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [610] = 7,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(132), 1,
      anon_sym_SEMI,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(103), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [642] = 9,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    ACTIONS(134), 1,
      anon_sym_RBRACE,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(22), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [678] = 9,
    ACTIONS(106), 1,
      anon_sym_if,
    ACTIONS(108), 1,
      anon_sym_do,
    ACTIONS(110), 1,
      anon_sym_return,
    ACTIONS(112), 1,
      anon_sym_print,
    ACTIONS(114), 1,
      anon_sym_input,
    ACTIONS(116), 1,
      sym_identifier,
    ACTIONS(136), 1,
      anon_sym_RBRACE,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(22), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [714] = 9,
    ACTIONS(7), 1,
      anon_sym_if,
    ACTIONS(9), 1,
      anon_sym_do,
    ACTIONS(11), 1,
      anon_sym_return,
    ACTIONS(13), 1,
      anon_sym_print,
    ACTIONS(15), 1,
      anon_sym_input,
    ACTIONS(19), 1,
      sym_identifier,
    ACTIONS(138), 1,
      anon_sym_LBRACE,
    STATE(141), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(47), 8,
      sym_block,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
  [750] = 9,
    ACTIONS(140), 1,
      anon_sym_RBRACE,
    ACTIONS(142), 1,
      anon_sym_if,
    ACTIONS(145), 1,
      anon_sym_do,
    ACTIONS(148), 1,
      anon_sym_return,
    ACTIONS(151), 1,
      anon_sym_print,
    ACTIONS(154), 1,
      anon_sym_input,
    ACTIONS(157), 1,
      sym_identifier,
    STATE(134), 2,
      sym_function_call,
      sym_post_increment_statement,
    STATE(22), 8,
      sym__statement,
      sym_if_statement,
      sym_do_while_statement,
      sym_return_statement,
      sym_print_statement,
      sym_input_statement,
      sym_assignment_statement,
      aux_sym_block_repeat1,
  [786] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(100), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [815] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(92), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [844] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(91), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [873] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(101), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [902] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(89), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [931] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(108), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [960] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(95), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [989] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(105), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1018] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(94), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1047] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(96), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1076] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(99), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1105] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(98), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1134] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(106), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1163] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(102), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1192] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(78), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
  [1221] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(88), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1250] = 6,
    ACTIONS(94), 1,
      anon_sym_LPAREN,
    ACTIONS(102), 1,
      sym_identifier,
    ACTIONS(98), 2,
      sym_literal_string,
      sym_literal_number,
    ACTIONS(100), 2,
      anon_sym_true,
      anon_sym_false,
    STATE(86), 5,
      sym_function_call,
      sym_post_increment_statement,
      sym_parenthesized_expression,
      sym__expression_value,
      sym_literal_boolean,
    STATE(87), 5,
      sym__expression,
      sym_or_expression,
      sym_equality_expression,
      sym_addition_expression,
      sym_value,
  [1279] = 2,
    ACTIONS(160), 1,
      ts_builtin_sym_end,
    ACTIONS(162), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1293] = 2,
    ACTIONS(164), 1,
      ts_builtin_sym_end,
    ACTIONS(166), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1307] = 2,
    ACTIONS(168), 1,
      ts_builtin_sym_end,
    ACTIONS(170), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1321] = 2,
    ACTIONS(172), 1,
      ts_builtin_sym_end,
    ACTIONS(174), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1335] = 2,
    ACTIONS(176), 1,
      ts_builtin_sym_end,
    ACTIONS(178), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1349] = 2,
    ACTIONS(180), 1,
      ts_builtin_sym_end,
    ACTIONS(182), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1363] = 2,
    ACTIONS(184), 1,
      ts_builtin_sym_end,
    ACTIONS(186), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1377] = 2,
    ACTIONS(188), 1,
      ts_builtin_sym_end,
    ACTIONS(190), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1391] = 2,
    ACTIONS(192), 1,
      ts_builtin_sym_end,
    ACTIONS(194), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1405] = 2,
    ACTIONS(196), 1,
      ts_builtin_sym_end,
    ACTIONS(198), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1419] = 2,
    ACTIONS(200), 1,
      ts_builtin_sym_end,
    ACTIONS(202), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1433] = 2,
    ACTIONS(204), 1,
      ts_builtin_sym_end,
    ACTIONS(206), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1447] = 2,
    ACTIONS(208), 1,
      ts_builtin_sym_end,
    ACTIONS(210), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1461] = 2,
    ACTIONS(212), 1,
      ts_builtin_sym_end,
    ACTIONS(214), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1475] = 2,
    ACTIONS(216), 1,
      ts_builtin_sym_end,
    ACTIONS(218), 8,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      anon_sym_function,
      sym_identifier,
  [1489] = 2,
    ACTIONS(164), 1,
      anon_sym_RBRACE,
    ACTIONS(166), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1502] = 2,
    ACTIONS(204), 1,
      anon_sym_RBRACE,
    ACTIONS(206), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1515] = 4,
    ACTIONS(222), 1,
      anon_sym_LPAREN,
    ACTIONS(224), 1,
      anon_sym_PLUS_PLUS,
    ACTIONS(226), 1,
      anon_sym_PLUS,
    ACTIONS(220), 5,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
  [1532] = 2,
    ACTIONS(200), 1,
      anon_sym_RBRACE,
    ACTIONS(202), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1545] = 2,
    ACTIONS(192), 1,
      anon_sym_RBRACE,
    ACTIONS(194), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1558] = 6,
    ACTIONS(230), 1,
      anon_sym_RPAREN,
    ACTIONS(232), 1,
      anon_sym_COMMA,
    STATE(115), 1,
      sym_argument_declaration,
    STATE(117), 1,
      aux_sym_argument_declaration_list_repeat1,
    STATE(150), 1,
      sym_type,
    ACTIONS(228), 3,
      anon_sym_int,
      anon_sym_boolean,
      anon_sym_string,
  [1579] = 2,
    ACTIONS(196), 1,
      anon_sym_RBRACE,
    ACTIONS(198), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1592] = 2,
    ACTIONS(188), 1,
      anon_sym_RBRACE,
    ACTIONS(190), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1605] = 2,
    ACTIONS(184), 1,
      anon_sym_RBRACE,
    ACTIONS(186), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1618] = 2,
    ACTIONS(160), 1,
      anon_sym_RBRACE,
    ACTIONS(162), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1631] = 2,
    ACTIONS(208), 1,
      anon_sym_RBRACE,
    ACTIONS(210), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1644] = 2,
    ACTIONS(168), 1,
      anon_sym_RBRACE,
    ACTIONS(170), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1657] = 2,
    ACTIONS(180), 1,
      anon_sym_RBRACE,
    ACTIONS(182), 7,
      anon_sym_let,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1670] = 2,
    ACTIONS(208), 1,
      anon_sym_RBRACE,
    ACTIONS(210), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1682] = 2,
    ACTIONS(160), 1,
      anon_sym_RBRACE,
    ACTIONS(162), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1694] = 2,
    ACTIONS(196), 1,
      anon_sym_RBRACE,
    ACTIONS(198), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1706] = 2,
    ACTIONS(200), 1,
      anon_sym_RBRACE,
    ACTIONS(202), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1718] = 2,
    ACTIONS(188), 1,
      anon_sym_RBRACE,
    ACTIONS(190), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1730] = 2,
    ACTIONS(164), 1,
      anon_sym_RBRACE,
    ACTIONS(166), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1742] = 2,
    ACTIONS(184), 1,
      anon_sym_RBRACE,
    ACTIONS(186), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1754] = 2,
    ACTIONS(192), 1,
      anon_sym_RBRACE,
    ACTIONS(194), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1766] = 2,
    ACTIONS(168), 1,
      anon_sym_RBRACE,
    ACTIONS(170), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1778] = 2,
    ACTIONS(180), 1,
      anon_sym_RBRACE,
    ACTIONS(182), 6,
      anon_sym_if,
      anon_sym_do,
      anon_sym_return,
      anon_sym_print,
      anon_sym_input,
      sym_identifier,
  [1790] = 3,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(234), 4,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
  [1803] = 1,
    ACTIONS(240), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1812] = 1,
    ACTIONS(242), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1821] = 1,
    ACTIONS(244), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1830] = 1,
    ACTIONS(246), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1839] = 1,
    ACTIONS(248), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1848] = 6,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(250), 1,
      anon_sym_RPAREN,
    ACTIONS(252), 1,
      anon_sym_COMMA,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    STATE(116), 1,
      aux_sym_argument_list_repeat1,
  [1867] = 4,
    ACTIONS(256), 1,
      anon_sym_LPAREN,
    STATE(122), 1,
      sym_argument_declaration_list,
    STATE(123), 1,
      sym_type,
    ACTIONS(228), 3,
      anon_sym_int,
      anon_sym_boolean,
      anon_sym_string,
  [1882] = 1,
    ACTIONS(220), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1891] = 1,
    ACTIONS(258), 6,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
      anon_sym_PLUS,
  [1900] = 2,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(260), 5,
      anon_sym_SEMI,
      anon_sym_RPAREN,
      anon_sym_COMMA,
      anon_sym_PIPE_PIPE,
      anon_sym_EQ_EQ,
  [1911] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(262), 2,
      anon_sym_RPAREN,
      anon_sym_COMMA,
  [1925] = 3,
    STATE(125), 1,
      sym_argument_declaration,
    STATE(150), 1,
      sym_type,
    ACTIONS(228), 3,
      anon_sym_int,
      anon_sym_boolean,
      anon_sym_string,
  [1937] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(264), 1,
      anon_sym_RPAREN,
  [1950] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(266), 1,
      anon_sym_RPAREN,
  [1963] = 2,
    STATE(127), 1,
      sym_type,
    ACTIONS(228), 3,
      anon_sym_int,
      anon_sym_boolean,
      anon_sym_string,
  [1972] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(268), 1,
      anon_sym_RPAREN,
  [1985] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(270), 1,
      anon_sym_RPAREN,
  [1998] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(272), 1,
      anon_sym_RPAREN,
  [2011] = 2,
    STATE(138), 1,
      sym_type,
    ACTIONS(228), 3,
      anon_sym_int,
      anon_sym_boolean,
      anon_sym_string,
  [2020] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(274), 1,
      anon_sym_RPAREN,
  [2033] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(276), 1,
      anon_sym_RPAREN,
  [2046] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(278), 1,
      anon_sym_RPAREN,
  [2059] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(280), 1,
      anon_sym_RPAREN,
  [2072] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(282), 1,
      anon_sym_SEMI,
  [2085] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(284), 1,
      anon_sym_SEMI,
  [2098] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(286), 1,
      anon_sym_SEMI,
  [2111] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(288), 1,
      anon_sym_RPAREN,
  [2124] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(290), 1,
      anon_sym_SEMI,
  [2137] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(292), 1,
      anon_sym_SEMI,
  [2150] = 4,
    ACTIONS(236), 1,
      anon_sym_EQ_EQ,
    ACTIONS(238), 1,
      anon_sym_PLUS,
    ACTIONS(254), 1,
      anon_sym_PIPE_PIPE,
    ACTIONS(294), 1,
      anon_sym_SEMI,
  [2163] = 3,
    ACTIONS(222), 1,
      anon_sym_LPAREN,
    ACTIONS(224), 1,
      anon_sym_PLUS_PLUS,
    ACTIONS(296), 1,
      anon_sym_EQ,
  [2173] = 3,
    ACTIONS(222), 1,
      anon_sym_LPAREN,
    ACTIONS(224), 1,
      anon_sym_PLUS_PLUS,
    ACTIONS(298), 1,
      anon_sym_EQ,
  [2183] = 3,
    ACTIONS(300), 1,
      anon_sym_RPAREN,
    ACTIONS(302), 1,
      anon_sym_COMMA,
    STATE(111), 1,
      aux_sym_argument_declaration_list_repeat1,
  [2193] = 3,
    ACTIONS(222), 1,
      anon_sym_LPAREN,
    ACTIONS(224), 1,
      anon_sym_PLUS_PLUS,
    ACTIONS(305), 1,
      anon_sym_EQ,
  [2203] = 3,
    ACTIONS(262), 1,
      anon_sym_RPAREN,
    ACTIONS(307), 1,
      anon_sym_COMMA,
    STATE(113), 1,
      aux_sym_argument_list_repeat1,
  [2213] = 3,
    ACTIONS(232), 1,
      anon_sym_COMMA,
    ACTIONS(310), 1,
      anon_sym_RPAREN,
    STATE(111), 1,
      aux_sym_argument_declaration_list_repeat1,
  [2223] = 3,
    ACTIONS(232), 1,
      anon_sym_COMMA,
    ACTIONS(312), 1,
      anon_sym_RPAREN,
    STATE(114), 1,
      aux_sym_argument_declaration_list_repeat1,
  [2233] = 3,
    ACTIONS(252), 1,
      anon_sym_COMMA,
    ACTIONS(314), 1,
      anon_sym_RPAREN,
    STATE(113), 1,
      aux_sym_argument_list_repeat1,
  [2243] = 3,
    ACTIONS(232), 1,
      anon_sym_COMMA,
    ACTIONS(312), 1,
      anon_sym_RPAREN,
    STATE(111), 1,
      aux_sym_argument_declaration_list_repeat1,
  [2253] = 2,
    ACTIONS(316), 1,
      anon_sym_LBRACE,
    STATE(43), 1,
      sym_block_and_declaration,
  [2260] = 2,
    ACTIONS(318), 1,
      anon_sym_LBRACE,
    STATE(170), 1,
      sym_block_and_declaration,
  [2267] = 2,
    ACTIONS(318), 1,
      anon_sym_LBRACE,
    STATE(169), 1,
      sym_block_and_declaration,
  [2274] = 2,
    ACTIONS(318), 1,
      anon_sym_LBRACE,
    STATE(135), 1,
      sym_block_and_declaration,
  [2281] = 2,
    ACTIONS(316), 1,
      anon_sym_LBRACE,
    STATE(53), 1,
      sym_block_and_declaration,
  [2288] = 2,
    ACTIONS(256), 1,
      anon_sym_LPAREN,
    STATE(118), 1,
      sym_argument_declaration_list,
  [2295] = 1,
    ACTIONS(320), 2,
      anon_sym_RPAREN,
      anon_sym_COMMA,
  [2300] = 1,
    ACTIONS(300), 2,
      anon_sym_RPAREN,
      anon_sym_COMMA,
  [2305] = 1,
    ACTIONS(322), 2,
      anon_sym_LPAREN,
      sym_identifier,
  [2310] = 1,
    ACTIONS(324), 1,
      sym_identifier,
  [2314] = 1,
    ACTIONS(326), 1,
      anon_sym_LBRACE,
  [2318] = 1,
    ACTIONS(328), 1,
      anon_sym_SEMI,
  [2322] = 1,
    ACTIONS(330), 1,
      anon_sym_SEMI,
  [2326] = 1,
    ACTIONS(332), 1,
      anon_sym_SEMI,
  [2330] = 1,
    ACTIONS(334), 1,
      sym_identifier,
  [2334] = 1,
    ACTIONS(336), 1,
      anon_sym_SEMI,
  [2338] = 1,
    ACTIONS(338), 1,
      anon_sym_SEMI,
  [2342] = 1,
    ACTIONS(340), 1,
      anon_sym_while,
  [2346] = 1,
    ACTIONS(342), 1,
      anon_sym_SEMI,
  [2350] = 1,
    ACTIONS(344), 1,
      anon_sym_SEMI,
  [2354] = 1,
    ACTIONS(346), 1,
      sym_identifier,
  [2358] = 1,
    ACTIONS(348), 1,
      anon_sym_SEMI,
  [2362] = 1,
    ACTIONS(350), 1,
      anon_sym_LBRACE,
  [2366] = 1,
    ACTIONS(352), 1,
      anon_sym_SEMI,
  [2370] = 1,
    ACTIONS(354), 1,
      anon_sym_SEMI,
  [2374] = 1,
    ACTIONS(356), 1,
      anon_sym_RPAREN,
  [2378] = 1,
    ACTIONS(358), 1,
      anon_sym_SEMI,
  [2382] = 1,
    ACTIONS(360), 1,
      ts_builtin_sym_end,
  [2386] = 1,
    ACTIONS(362), 1,
      anon_sym_LBRACE,
  [2390] = 1,
    ACTIONS(216), 1,
      anon_sym_while,
  [2394] = 1,
    ACTIONS(364), 1,
      anon_sym_RPAREN,
  [2398] = 1,
    ACTIONS(366), 1,
      anon_sym_SEMI,
  [2402] = 1,
    ACTIONS(368), 1,
      sym_identifier,
  [2406] = 1,
    ACTIONS(370), 1,
      anon_sym_LPAREN,
  [2410] = 1,
    ACTIONS(372), 1,
      anon_sym_SEMI,
  [2414] = 1,
    ACTIONS(374), 1,
      sym_identifier,
  [2418] = 1,
    ACTIONS(376), 1,
      sym_identifier,
  [2422] = 1,
    ACTIONS(378), 1,
      anon_sym_LPAREN,
  [2426] = 1,
    ACTIONS(380), 1,
      anon_sym_RPAREN,
  [2430] = 1,
    ACTIONS(382), 1,
      anon_sym_LPAREN,
  [2434] = 1,
    ACTIONS(384), 1,
      anon_sym_RPAREN,
  [2438] = 1,
    ACTIONS(386), 1,
      sym_identifier,
  [2442] = 1,
    ACTIONS(388), 1,
      anon_sym_LPAREN,
  [2446] = 1,
    ACTIONS(390), 1,
      anon_sym_LPAREN,
  [2450] = 1,
    ACTIONS(392), 1,
      anon_sym_LPAREN,
  [2454] = 1,
    ACTIONS(394), 1,
      anon_sym_LPAREN,
  [2458] = 1,
    ACTIONS(396), 1,
      anon_sym_LPAREN,
  [2462] = 1,
    ACTIONS(398), 1,
      anon_sym_LPAREN,
  [2466] = 1,
    ACTIONS(400), 1,
      anon_sym_LPAREN,
  [2470] = 1,
    ACTIONS(402), 1,
      anon_sym_LPAREN,
  [2474] = 1,
    ACTIONS(404), 1,
      anon_sym_LPAREN,
  [2478] = 1,
    ACTIONS(406), 1,
      anon_sym_while,
  [2482] = 1,
    ACTIONS(408), 1,
      anon_sym_while,
  [2486] = 1,
    ACTIONS(176), 1,
      anon_sym_while,
  [2490] = 1,
    ACTIONS(410), 1,
      anon_sym_SEMI,
};

static const uint32_t ts_small_parse_table_map[] = {
  [SMALL_STATE(2)] = 0,
  [SMALL_STATE(3)] = 45,
  [SMALL_STATE(4)] = 90,
  [SMALL_STATE(5)] = 131,
  [SMALL_STATE(6)] = 172,
  [SMALL_STATE(7)] = 213,
  [SMALL_STATE(8)] = 254,
  [SMALL_STATE(9)] = 295,
  [SMALL_STATE(10)] = 330,
  [SMALL_STATE(11)] = 366,
  [SMALL_STATE(12)] = 402,
  [SMALL_STATE(13)] = 434,
  [SMALL_STATE(14)] = 466,
  [SMALL_STATE(15)] = 502,
  [SMALL_STATE(16)] = 538,
  [SMALL_STATE(17)] = 574,
  [SMALL_STATE(18)] = 610,
  [SMALL_STATE(19)] = 642,
  [SMALL_STATE(20)] = 678,
  [SMALL_STATE(21)] = 714,
  [SMALL_STATE(22)] = 750,
  [SMALL_STATE(23)] = 786,
  [SMALL_STATE(24)] = 815,
  [SMALL_STATE(25)] = 844,
  [SMALL_STATE(26)] = 873,
  [SMALL_STATE(27)] = 902,
  [SMALL_STATE(28)] = 931,
  [SMALL_STATE(29)] = 960,
  [SMALL_STATE(30)] = 989,
  [SMALL_STATE(31)] = 1018,
  [SMALL_STATE(32)] = 1047,
  [SMALL_STATE(33)] = 1076,
  [SMALL_STATE(34)] = 1105,
  [SMALL_STATE(35)] = 1134,
  [SMALL_STATE(36)] = 1163,
  [SMALL_STATE(37)] = 1192,
  [SMALL_STATE(38)] = 1221,
  [SMALL_STATE(39)] = 1250,
  [SMALL_STATE(40)] = 1279,
  [SMALL_STATE(41)] = 1293,
  [SMALL_STATE(42)] = 1307,
  [SMALL_STATE(43)] = 1321,
  [SMALL_STATE(44)] = 1335,
  [SMALL_STATE(45)] = 1349,
  [SMALL_STATE(46)] = 1363,
  [SMALL_STATE(47)] = 1377,
  [SMALL_STATE(48)] = 1391,
  [SMALL_STATE(49)] = 1405,
  [SMALL_STATE(50)] = 1419,
  [SMALL_STATE(51)] = 1433,
  [SMALL_STATE(52)] = 1447,
  [SMALL_STATE(53)] = 1461,
  [SMALL_STATE(54)] = 1475,
  [SMALL_STATE(55)] = 1489,
  [SMALL_STATE(56)] = 1502,
  [SMALL_STATE(57)] = 1515,
  [SMALL_STATE(58)] = 1532,
  [SMALL_STATE(59)] = 1545,
  [SMALL_STATE(60)] = 1558,
  [SMALL_STATE(61)] = 1579,
  [SMALL_STATE(62)] = 1592,
  [SMALL_STATE(63)] = 1605,
  [SMALL_STATE(64)] = 1618,
  [SMALL_STATE(65)] = 1631,
  [SMALL_STATE(66)] = 1644,
  [SMALL_STATE(67)] = 1657,
  [SMALL_STATE(68)] = 1670,
  [SMALL_STATE(69)] = 1682,
  [SMALL_STATE(70)] = 1694,
  [SMALL_STATE(71)] = 1706,
  [SMALL_STATE(72)] = 1718,
  [SMALL_STATE(73)] = 1730,
  [SMALL_STATE(74)] = 1742,
  [SMALL_STATE(75)] = 1754,
  [SMALL_STATE(76)] = 1766,
  [SMALL_STATE(77)] = 1778,
  [SMALL_STATE(78)] = 1790,
  [SMALL_STATE(79)] = 1803,
  [SMALL_STATE(80)] = 1812,
  [SMALL_STATE(81)] = 1821,
  [SMALL_STATE(82)] = 1830,
  [SMALL_STATE(83)] = 1839,
  [SMALL_STATE(84)] = 1848,
  [SMALL_STATE(85)] = 1867,
  [SMALL_STATE(86)] = 1882,
  [SMALL_STATE(87)] = 1891,
  [SMALL_STATE(88)] = 1900,
  [SMALL_STATE(89)] = 1911,
  [SMALL_STATE(90)] = 1925,
  [SMALL_STATE(91)] = 1937,
  [SMALL_STATE(92)] = 1950,
  [SMALL_STATE(93)] = 1963,
  [SMALL_STATE(94)] = 1972,
  [SMALL_STATE(95)] = 1985,
  [SMALL_STATE(96)] = 1998,
  [SMALL_STATE(97)] = 2011,
  [SMALL_STATE(98)] = 2020,
  [SMALL_STATE(99)] = 2033,
  [SMALL_STATE(100)] = 2046,
  [SMALL_STATE(101)] = 2059,
  [SMALL_STATE(102)] = 2072,
  [SMALL_STATE(103)] = 2085,
  [SMALL_STATE(104)] = 2098,
  [SMALL_STATE(105)] = 2111,
  [SMALL_STATE(106)] = 2124,
  [SMALL_STATE(107)] = 2137,
  [SMALL_STATE(108)] = 2150,
  [SMALL_STATE(109)] = 2163,
  [SMALL_STATE(110)] = 2173,
  [SMALL_STATE(111)] = 2183,
  [SMALL_STATE(112)] = 2193,
  [SMALL_STATE(113)] = 2203,
  [SMALL_STATE(114)] = 2213,
  [SMALL_STATE(115)] = 2223,
  [SMALL_STATE(116)] = 2233,
  [SMALL_STATE(117)] = 2243,
  [SMALL_STATE(118)] = 2253,
  [SMALL_STATE(119)] = 2260,
  [SMALL_STATE(120)] = 2267,
  [SMALL_STATE(121)] = 2274,
  [SMALL_STATE(122)] = 2281,
  [SMALL_STATE(123)] = 2288,
  [SMALL_STATE(124)] = 2295,
  [SMALL_STATE(125)] = 2300,
  [SMALL_STATE(126)] = 2305,
  [SMALL_STATE(127)] = 2310,
  [SMALL_STATE(128)] = 2314,
  [SMALL_STATE(129)] = 2318,
  [SMALL_STATE(130)] = 2322,
  [SMALL_STATE(131)] = 2326,
  [SMALL_STATE(132)] = 2330,
  [SMALL_STATE(133)] = 2334,
  [SMALL_STATE(134)] = 2338,
  [SMALL_STATE(135)] = 2342,
  [SMALL_STATE(136)] = 2346,
  [SMALL_STATE(137)] = 2350,
  [SMALL_STATE(138)] = 2354,
  [SMALL_STATE(139)] = 2358,
  [SMALL_STATE(140)] = 2362,
  [SMALL_STATE(141)] = 2366,
  [SMALL_STATE(142)] = 2370,
  [SMALL_STATE(143)] = 2374,
  [SMALL_STATE(144)] = 2378,
  [SMALL_STATE(145)] = 2382,
  [SMALL_STATE(146)] = 2386,
  [SMALL_STATE(147)] = 2390,
  [SMALL_STATE(148)] = 2394,
  [SMALL_STATE(149)] = 2398,
  [SMALL_STATE(150)] = 2402,
  [SMALL_STATE(151)] = 2406,
  [SMALL_STATE(152)] = 2410,
  [SMALL_STATE(153)] = 2414,
  [SMALL_STATE(154)] = 2418,
  [SMALL_STATE(155)] = 2422,
  [SMALL_STATE(156)] = 2426,
  [SMALL_STATE(157)] = 2430,
  [SMALL_STATE(158)] = 2434,
  [SMALL_STATE(159)] = 2438,
  [SMALL_STATE(160)] = 2442,
  [SMALL_STATE(161)] = 2446,
  [SMALL_STATE(162)] = 2450,
  [SMALL_STATE(163)] = 2454,
  [SMALL_STATE(164)] = 2458,
  [SMALL_STATE(165)] = 2462,
  [SMALL_STATE(166)] = 2466,
  [SMALL_STATE(167)] = 2470,
  [SMALL_STATE(168)] = 2474,
  [SMALL_STATE(169)] = 2478,
  [SMALL_STATE(170)] = 2482,
  [SMALL_STATE(171)] = 2486,
  [SMALL_STATE(172)] = 2490,
};

static const TSParseActionEntry ts_parse_actions[] = {
  [0] = {.entry = {.count = 0, .reusable = false}},
  [1] = {.entry = {.count = 1, .reusable = false}}, RECOVER(),
  [3] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_program, 0),
  [5] = {.entry = {.count = 1, .reusable = false}}, SHIFT(97),
  [7] = {.entry = {.count = 1, .reusable = false}}, SHIFT(160),
  [9] = {.entry = {.count = 1, .reusable = false}}, SHIFT(121),
  [11] = {.entry = {.count = 1, .reusable = false}}, SHIFT(13),
  [13] = {.entry = {.count = 1, .reusable = false}}, SHIFT(157),
  [15] = {.entry = {.count = 1, .reusable = false}}, SHIFT(155),
  [17] = {.entry = {.count = 1, .reusable = false}}, SHIFT(153),
  [19] = {.entry = {.count = 1, .reusable = false}}, SHIFT(109),
  [21] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_program_repeat1, 2),
  [23] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(97),
  [26] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(160),
  [29] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(121),
  [32] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(13),
  [35] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(157),
  [38] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(155),
  [41] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(153),
  [44] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_program_repeat1, 2), SHIFT_REPEAT(109),
  [47] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_program, 1),
  [49] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2),
  [51] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(93),
  [54] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(161),
  [57] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(120),
  [60] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(12),
  [63] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(162),
  [66] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(163),
  [69] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_and_declaration_repeat1, 2), SHIFT_REPEAT(112),
  [72] = {.entry = {.count = 1, .reusable = true}}, SHIFT(171),
  [74] = {.entry = {.count = 1, .reusable = false}}, SHIFT(93),
  [76] = {.entry = {.count = 1, .reusable = false}}, SHIFT(161),
  [78] = {.entry = {.count = 1, .reusable = false}}, SHIFT(120),
  [80] = {.entry = {.count = 1, .reusable = false}}, SHIFT(12),
  [82] = {.entry = {.count = 1, .reusable = false}}, SHIFT(162),
  [84] = {.entry = {.count = 1, .reusable = false}}, SHIFT(163),
  [86] = {.entry = {.count = 1, .reusable = false}}, SHIFT(112),
  [88] = {.entry = {.count = 1, .reusable = true}}, SHIFT(54),
  [90] = {.entry = {.count = 1, .reusable = true}}, SHIFT(44),
  [92] = {.entry = {.count = 1, .reusable = true}}, SHIFT(147),
  [94] = {.entry = {.count = 1, .reusable = true}}, SHIFT(24),
  [96] = {.entry = {.count = 1, .reusable = true}}, SHIFT(81),
  [98] = {.entry = {.count = 1, .reusable = true}}, SHIFT(86),
  [100] = {.entry = {.count = 1, .reusable = false}}, SHIFT(82),
  [102] = {.entry = {.count = 1, .reusable = false}}, SHIFT(57),
  [104] = {.entry = {.count = 1, .reusable = true}}, SHIFT(55),
  [106] = {.entry = {.count = 1, .reusable = false}}, SHIFT(165),
  [108] = {.entry = {.count = 1, .reusable = false}}, SHIFT(119),
  [110] = {.entry = {.count = 1, .reusable = false}}, SHIFT(18),
  [112] = {.entry = {.count = 1, .reusable = false}}, SHIFT(166),
  [114] = {.entry = {.count = 1, .reusable = false}}, SHIFT(167),
  [116] = {.entry = {.count = 1, .reusable = false}}, SHIFT(110),
  [118] = {.entry = {.count = 1, .reusable = true}}, SHIFT(10),
  [120] = {.entry = {.count = 1, .reusable = true}}, SHIFT(59),
  [122] = {.entry = {.count = 1, .reusable = true}}, SHIFT(48),
  [124] = {.entry = {.count = 1, .reusable = true}}, SHIFT(68),
  [126] = {.entry = {.count = 1, .reusable = true}}, SHIFT(73),
  [128] = {.entry = {.count = 1, .reusable = true}}, SHIFT(15),
  [130] = {.entry = {.count = 1, .reusable = true}}, SHIFT(41),
  [132] = {.entry = {.count = 1, .reusable = true}}, SHIFT(75),
  [134] = {.entry = {.count = 1, .reusable = true}}, SHIFT(52),
  [136] = {.entry = {.count = 1, .reusable = true}}, SHIFT(65),
  [138] = {.entry = {.count = 1, .reusable = true}}, SHIFT(17),
  [140] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_block_repeat1, 2),
  [142] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_repeat1, 2), SHIFT_REPEAT(165),
  [145] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_repeat1, 2), SHIFT_REPEAT(119),
  [148] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_repeat1, 2), SHIFT_REPEAT(18),
  [151] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_repeat1, 2), SHIFT_REPEAT(166),
  [154] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_repeat1, 2), SHIFT_REPEAT(167),
  [157] = {.entry = {.count = 2, .reusable = false}}, REDUCE(aux_sym_block_repeat1, 2), SHIFT_REPEAT(110),
  [160] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_do_while_statement, 7, .production_id = 7),
  [162] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_do_while_statement, 7, .production_id = 7),
  [164] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_block, 2),
  [166] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_block, 2),
  [168] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_return_statement, 3, .production_id = 2),
  [170] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_return_statement, 3, .production_id = 2),
  [172] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_function_declaration, 5),
  [174] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_function_declaration, 5),
  [176] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_block_and_declaration, 3),
  [178] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_block_and_declaration, 3),
  [180] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_input_statement, 5),
  [182] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_input_statement, 5),
  [184] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_print_statement, 5),
  [186] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_print_statement, 5),
  [188] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_if_statement, 5, .production_id = 5),
  [190] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_if_statement, 5, .production_id = 5),
  [192] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_return_statement, 2),
  [194] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_return_statement, 2),
  [196] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_assignment_statement, 4, .production_id = 4),
  [198] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_assignment_statement, 4, .production_id = 4),
  [200] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym__statement, 2),
  [202] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym__statement, 2),
  [204] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_let_statement, 4, .production_id = 3),
  [206] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_let_statement, 4, .production_id = 3),
  [208] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_block, 3),
  [210] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_block, 3),
  [212] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_function_declaration, 4),
  [214] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_function_declaration, 4),
  [216] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_block_and_declaration, 2),
  [218] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_block_and_declaration, 2),
  [220] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_value, 1),
  [222] = {.entry = {.count = 1, .reusable = true}}, SHIFT(9),
  [224] = {.entry = {.count = 1, .reusable = true}}, SHIFT(79),
  [226] = {.entry = {.count = 1, .reusable = false}}, REDUCE(sym_value, 1),
  [228] = {.entry = {.count = 1, .reusable = true}}, SHIFT(126),
  [230] = {.entry = {.count = 1, .reusable = true}}, SHIFT(140),
  [232] = {.entry = {.count = 1, .reusable = true}}, SHIFT(90),
  [234] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_or_expression, 3),
  [236] = {.entry = {.count = 1, .reusable = true}}, SHIFT(38),
  [238] = {.entry = {.count = 1, .reusable = true}}, SHIFT(39),
  [240] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_post_increment_statement, 2),
  [242] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_function_call, 4),
  [244] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_function_call, 3),
  [246] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_literal_boolean, 1),
  [248] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_parenthesized_expression, 3),
  [250] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_argument_list, 1),
  [252] = {.entry = {.count = 1, .reusable = true}}, SHIFT(27),
  [254] = {.entry = {.count = 1, .reusable = true}}, SHIFT(37),
  [256] = {.entry = {.count = 1, .reusable = true}}, SHIFT(60),
  [258] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_addition_expression, 3),
  [260] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_equality_expression, 3),
  [262] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_argument_list_repeat1, 2),
  [264] = {.entry = {.count = 1, .reusable = true}}, SHIFT(172),
  [266] = {.entry = {.count = 1, .reusable = true}}, SHIFT(83),
  [268] = {.entry = {.count = 1, .reusable = true}}, SHIFT(139),
  [270] = {.entry = {.count = 1, .reusable = true}}, SHIFT(136),
  [272] = {.entry = {.count = 1, .reusable = true}}, SHIFT(16),
  [274] = {.entry = {.count = 1, .reusable = true}}, SHIFT(133),
  [276] = {.entry = {.count = 1, .reusable = true}}, SHIFT(129),
  [278] = {.entry = {.count = 1, .reusable = true}}, SHIFT(11),
  [280] = {.entry = {.count = 1, .reusable = true}}, SHIFT(144),
  [282] = {.entry = {.count = 1, .reusable = true}}, SHIFT(70),
  [284] = {.entry = {.count = 1, .reusable = true}}, SHIFT(76),
  [286] = {.entry = {.count = 1, .reusable = true}}, SHIFT(42),
  [288] = {.entry = {.count = 1, .reusable = true}}, SHIFT(21),
  [290] = {.entry = {.count = 1, .reusable = true}}, SHIFT(61),
  [292] = {.entry = {.count = 1, .reusable = true}}, SHIFT(66),
  [294] = {.entry = {.count = 1, .reusable = true}}, SHIFT(49),
  [296] = {.entry = {.count = 1, .reusable = true}}, SHIFT(28),
  [298] = {.entry = {.count = 1, .reusable = true}}, SHIFT(36),
  [300] = {.entry = {.count = 1, .reusable = true}}, REDUCE(aux_sym_argument_declaration_list_repeat1, 2),
  [302] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_argument_declaration_list_repeat1, 2), SHIFT_REPEAT(90),
  [305] = {.entry = {.count = 1, .reusable = true}}, SHIFT(35),
  [307] = {.entry = {.count = 2, .reusable = true}}, REDUCE(aux_sym_argument_list_repeat1, 2), SHIFT_REPEAT(27),
  [310] = {.entry = {.count = 1, .reusable = true}}, SHIFT(128),
  [312] = {.entry = {.count = 1, .reusable = true}}, SHIFT(146),
  [314] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_argument_list, 2),
  [316] = {.entry = {.count = 1, .reusable = true}}, SHIFT(6),
  [318] = {.entry = {.count = 1, .reusable = true}}, SHIFT(8),
  [320] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_argument_declaration, 2, .production_id = 6),
  [322] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_type, 1, .production_id = 1),
  [324] = {.entry = {.count = 1, .reusable = true}}, SHIFT(149),
  [326] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_argument_declaration_list, 4),
  [328] = {.entry = {.count = 1, .reusable = true}}, SHIFT(63),
  [330] = {.entry = {.count = 1, .reusable = true}}, SHIFT(67),
  [332] = {.entry = {.count = 1, .reusable = true}}, SHIFT(51),
  [334] = {.entry = {.count = 1, .reusable = true}}, SHIFT(156),
  [336] = {.entry = {.count = 1, .reusable = true}}, SHIFT(64),
  [338] = {.entry = {.count = 1, .reusable = true}}, SHIFT(71),
  [340] = {.entry = {.count = 1, .reusable = true}}, SHIFT(151),
  [342] = {.entry = {.count = 1, .reusable = true}}, SHIFT(74),
  [344] = {.entry = {.count = 1, .reusable = true}}, SHIFT(77),
  [346] = {.entry = {.count = 1, .reusable = true}}, SHIFT(131),
  [348] = {.entry = {.count = 1, .reusable = true}}, SHIFT(69),
  [350] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_argument_declaration_list, 2),
  [352] = {.entry = {.count = 1, .reusable = true}}, SHIFT(50),
  [354] = {.entry = {.count = 1, .reusable = true}}, SHIFT(45),
  [356] = {.entry = {.count = 1, .reusable = true}}, SHIFT(130),
  [358] = {.entry = {.count = 1, .reusable = true}}, SHIFT(40),
  [360] = {.entry = {.count = 1, .reusable = true}},  ACCEPT_INPUT(),
  [362] = {.entry = {.count = 1, .reusable = true}}, REDUCE(sym_argument_declaration_list, 3),
  [364] = {.entry = {.count = 1, .reusable = true}}, SHIFT(137),
  [366] = {.entry = {.count = 1, .reusable = true}}, SHIFT(56),
  [368] = {.entry = {.count = 1, .reusable = true}}, SHIFT(124),
  [370] = {.entry = {.count = 1, .reusable = true}}, SHIFT(26),
  [372] = {.entry = {.count = 1, .reusable = true}}, SHIFT(58),
  [374] = {.entry = {.count = 1, .reusable = true}}, SHIFT(85),
  [376] = {.entry = {.count = 1, .reusable = true}}, SHIFT(143),
  [378] = {.entry = {.count = 1, .reusable = true}}, SHIFT(132),
  [380] = {.entry = {.count = 1, .reusable = true}}, SHIFT(142),
  [382] = {.entry = {.count = 1, .reusable = true}}, SHIFT(25),
  [384] = {.entry = {.count = 1, .reusable = true}}, SHIFT(80),
  [386] = {.entry = {.count = 1, .reusable = true}}, SHIFT(148),
  [388] = {.entry = {.count = 1, .reusable = true}}, SHIFT(30),
  [390] = {.entry = {.count = 1, .reusable = true}}, SHIFT(23),
  [392] = {.entry = {.count = 1, .reusable = true}}, SHIFT(33),
  [394] = {.entry = {.count = 1, .reusable = true}}, SHIFT(154),
  [396] = {.entry = {.count = 1, .reusable = true}}, SHIFT(34),
  [398] = {.entry = {.count = 1, .reusable = true}}, SHIFT(32),
  [400] = {.entry = {.count = 1, .reusable = true}}, SHIFT(29),
  [402] = {.entry = {.count = 1, .reusable = true}}, SHIFT(159),
  [404] = {.entry = {.count = 1, .reusable = true}}, SHIFT(31),
  [406] = {.entry = {.count = 1, .reusable = true}}, SHIFT(164),
  [408] = {.entry = {.count = 1, .reusable = true}}, SHIFT(168),
  [410] = {.entry = {.count = 1, .reusable = true}}, SHIFT(46),
};

#ifdef __cplusplus
extern "C" {
#endif
#ifdef _WIN32
#define extern __declspec(dllexport)
#endif

extern const TSLanguage *tree_sitter_jspdl(void) {
  static const TSLanguage language = {
    .version = LANGUAGE_VERSION,
    .symbol_count = SYMBOL_COUNT,
    .alias_count = ALIAS_COUNT,
    .token_count = TOKEN_COUNT,
    .external_token_count = EXTERNAL_TOKEN_COUNT,
    .state_count = STATE_COUNT,
    .large_state_count = LARGE_STATE_COUNT,
    .production_id_count = PRODUCTION_ID_COUNT,
    .field_count = FIELD_COUNT,
    .max_alias_sequence_length = MAX_ALIAS_SEQUENCE_LENGTH,
    .parse_table = &ts_parse_table[0][0],
    .small_parse_table = ts_small_parse_table,
    .small_parse_table_map = ts_small_parse_table_map,
    .parse_actions = ts_parse_actions,
    .symbol_names = ts_symbol_names,
    .field_names = ts_field_names,
    .field_map_slices = ts_field_map_slices,
    .field_map_entries = ts_field_map_entries,
    .symbol_metadata = ts_symbol_metadata,
    .public_symbol_map = ts_symbol_map,
    .alias_map = ts_non_terminal_alias_map,
    .alias_sequences = &ts_alias_sequences[0][0],
    .lex_modes = ts_lex_modes,
    .lex_fn = ts_lex,
    .primary_state_ids = ts_primary_state_ids,
  };
  return &language;
}
#ifdef __cplusplus
}
#endif
